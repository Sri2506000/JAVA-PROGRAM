# ecom-app-backend

Ecommere application using new Tech Spring boot Angular, Okta, and Bootstrap

https://www.youtube.com/watch?v=G6Nj1PcNomQ

Frontend Part ( with Angular ): https://github.com/ouhamzalhss/ecom-app-frontend
